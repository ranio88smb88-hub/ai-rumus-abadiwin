
import { createClient } from 'https://esm.sh/@supabase/supabase-js@2';
import { UserProfile, AIHistoryItem } from '../types';

const supabaseUrl = process.env.NEXT_PUBLIC_SUPABASE_URL || '';
const supabaseAnonKey = process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY || '';

export const supabase = createClient(supabaseUrl, supabaseAnonKey);

export const supabaseService = {
  async login(email: string) {
    // Simulasi login sederhana yang langsung mendaftarkan user ke tabel profil jika belum ada
    // Di produksi, ini biasanya dipicu oleh callback Google Auth atau Magic Link
    let { data: profile, error } = await supabase
      .from('profiles')
      .select('*')
      .eq('email', email)
      .single();
      
    if (!profile) {
      const { data: newProfile, error: insertError } = await supabase
        .from('profiles')
        .insert([{ email, role: 'operator' }])
        .select()
        .single();
      if (insertError) throw insertError;
      profile = newProfile;
    }
    
    localStorage.setItem('op_user', JSON.stringify(profile));
    return profile;
  },

  async getCurrentUser(): Promise<UserProfile | null> {
    const saved = localStorage.getItem('op_user');
    return saved ? JSON.parse(saved) : null;
  },

  async logout() {
    localStorage.removeItem('op_user');
    await supabase.auth.signOut();
  },

  async addHistory(item: Omit<AIHistoryItem, 'id' | 'created_at'>) {
    const { data, error } = await supabase
      .from('ai_history')
      .insert([item])
      .select()
      .single();
    if (error) {
      console.warn("RLS mungkin membatasi insert, pastikan kebijakan SQL sudah dijalankan.");
      throw error;
    }
    return data;
  },

  async getHistory() {
    const user = await this.getCurrentUser();
    if (!user) return [];
    
    let query = supabase.from('ai_history').select('*').order('created_at', { ascending: false });
    
    // Jika bukan admin, hanya ambil data miliknya sendiri
    if (user.role !== 'admin') {
      query = query.eq('user_id', user.id);
    }
    
    const { data, error } = await query;
    if (error) throw error;
    return data || [];
  },

  async deleteHistory(id: string) {
    const { error } = await supabase.from('ai_history').delete().eq('id', id);
    if (error) throw error;
  },

  async clearGlobalHistory() {
    const { error } = await supabase.from('ai_history').delete().neq('id', '00000000-0000-0000-0000-000000000000');
    if (error) throw error;
  },

  async getAllUsers() {
    const { data, error } = await supabase.from('profiles').select('*').order('created_at', { ascending: false });
    if (error) throw error;
    return data || [];
  },

  async promoteUser(id: string) {
    const { error } = await supabase
      .from('profiles')
      .update({ role: 'admin' })
      .eq('id', id);
    if (error) throw error;
  },

  async deleteUser(id: string) {
    const { error } = await supabase.from('profiles').delete().eq('id', id);
    if (error) throw error;
  },

  async getStats() {
    const [historyRes, usersRes] = await Promise.all([
      supabase.from('ai_history').select('type', { count: 'exact' }),
      supabase.from('profiles').select('id', { count: 'exact' })
    ]);

    const history = historyRes.data || [];
    return {
      totalRequests: historyRes.count || 0,
      activeUsers: usersRes.count || 0,
      types: {
        generator: history.filter(h => h.type === 'generator').length,
        checker: history.filter(h => h.type === 'error').length,
        ideas: history.filter(h => h.type === 'idea').length,
        analysis: history.filter(h => h.type === 'sheet-analysis').length,
      }
    };
  }
};
